"""Build the thesis as PDF and, optionally, as Word.

    python build.py            PDF (pdflatex, BibTeX, makeglossaries, pdflatex twice) -> main.pdf
    python build.py --docx     also Thesis.docx (needs pandoc and: pip install git+https://github.com/GeospatialGeeks/research-helpers)
    python build.py --docx --downloads   also copies both to downloads/ (the ready-made files offered in the README)

The Word version keeps the chapter, section, table and figure numbers and the cross-references of the PDF, uses the
Ulster Harvard style (ulster-harvard-lhs.csl) and the Ulster page set-up (A4, binding margin 40 mm, Arial 12 pt, 1.5
line spacing), with the title page, roman page numbers for the preliminary pages, contents and lists as Word fields.
A figure that exists only as PDF is converted to PNG for Word automatically.
"""
import pathlib, re, shutil, subprocess, sys

HERE = pathlib.Path(__file__).resolve().parent


def run(cmd):
    return subprocess.run(cmd, cwd=HERE, capture_output=True, text=True, errors="replace")


def pdf():
    for c in (["pdflatex", "-interaction=nonstopmode", "main.tex"], ["bibtex", "main"], ["makeglossaries", "main"],
              ["pdflatex", "-interaction=nonstopmode", "main.tex"], ["pdflatex", "-interaction=nonstopmode", "main.tex"]):
        run(c)
    log = (HERE / "main.log").read_text(encoding="utf-8", errors="replace")
    errors = sorted(set(re.findall(r"^! (.*)$", log, re.M)))
    undef = sorted(set(re.findall(r"(?:Reference|Citation) `([^']+)' on page \d+ undefined", log)))
    print(f"PDF: {len(errors)} errors, {len(undef)} undefined references or citations"
          + (": " + ", ".join(errors + undef) if errors or undef else ""))


def info(key):
    t = (HERE / "thesis-info.tex").read_text(encoding="utf-8")
    m = re.search(r"\\newcommand\{\\" + key + r"\}\{(.*?)\}\s*$", t, re.M)
    return m.group(1) if m else ""


def docx():
    try:
        from research_helpers.latex2docx import convert, PageSetup, TitlePage
    except ImportError:
        sys.exit("install research-helpers for the Word version: pip install git+https://github.com/GeospatialGeeks/research-helpers")
    front = (f"\\textbf{{{info('ThesisTitle')}}}\n\n{info('ThesisAuthor')}\n\n{info('ThesisFaculty')} of Ulster University\n\n"
             f"Thesis submitted for the degree of {info('ThesisDegree')}\n\n{info('SubmissionMonthYear')}\n\n"
             "I confirm that the word count of this thesis is less than 100,000 words excluding the title page, contents, "
             "acknowledgements, summary or abstract, abbreviations, footnotes, diagrams, maps, illustrations, tables, appendices, "
             "and references or bibliography.\n\n")
    # title page as in main.tex: title (Large, bold), 2 cm, name (large), 1.5 cm, faculty, 1 cm, degree, 1 cm, date;
    # the word-count statement at the foot of the page; no page number on it
    code = convert(HERE / "main.tex", HERE / "Thesis.docx", csl=HERE / "ulster-harvard-lhs.csl", front_matter=front,
                   page=PageSetup(left_mm=40, right_mm=25, top_mm=25, bottom_mm=25, font="Arial", size_pt=12, line_spacing=1.5),
                   title_page=TitlePage(sizes_pt=(17.28, 14.4), gaps_mm=(0, 20, 15, 10, 10), bottom=1))
    print("Word:", "Thesis.docx" if code == 0 else f"failed ({code})")


def overleaf_zip():
    """downloads/Ulster-thesis-template-Overleaf.zip: the LaTeX source only, files at the top level, ready for Overleaf
    (New Project, Upload Project) or any LaTeX editor. Fixed timestamps, so an unchanged source gives an identical zip."""
    import zipfile
    files = ["main.tex", "thesis-info.tex", "references.bib", "ulster-harvard-lhs.csl", "latexmkrc", "build.py",
             "README.md", "LICENSE"]
    files += sorted(str(p.relative_to(HERE)).replace("\\", "/") for d in ("chapters", "figures") for p in (HERE / d).iterdir()
                    if p.is_file())
    out = HERE / "downloads" / "Ulster-thesis-template-Overleaf.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            info = zipfile.ZipInfo(f, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, (HERE / f).read_bytes())
    print("downloads/" + out.name, f"({len(files)} files)")


if __name__ == "__main__":
    pdf()
    if "--docx" in sys.argv:
        docx()
    if "--downloads" in sys.argv:
        (HERE / "downloads").mkdir(exist_ok=True)
        for src, name in (("main.pdf", "Ulster-thesis-template.pdf"), ("Thesis.docx", "Ulster-thesis-template.docx")):
            if (HERE / src).exists():
                shutil.copy2(HERE / src, HERE / "downloads" / name)
                print("downloads/" + name)
        overleaf_zip()
